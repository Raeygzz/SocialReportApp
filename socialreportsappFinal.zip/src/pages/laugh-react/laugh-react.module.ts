import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LaughReactPage } from './laugh-react';

@NgModule({
  declarations: [
    LaughReactPage,
  ],
  imports: [
    IonicPageModule.forChild(LaughReactPage),
  ],
})
export class LaughReactPageModule {}
