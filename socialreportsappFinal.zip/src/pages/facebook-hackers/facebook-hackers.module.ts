import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FacebookHackersPage } from './facebook-hackers';

@NgModule({
  declarations: [
    FacebookHackersPage,
  ],
  imports: [
    IonicPageModule.forChild(FacebookHackersPage),
  ],
})
export class FacebookHackersPageModule {}
