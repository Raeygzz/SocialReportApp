import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LikesMeMostFbPage } from './likes-me-most-fb';

@NgModule({
  declarations: [
    LikesMeMostFbPage,
  ],
  imports: [
    IonicPageModule.forChild(LikesMeMostFbPage),
  ],
})
export class LikesMeMostFbPageModule {}
