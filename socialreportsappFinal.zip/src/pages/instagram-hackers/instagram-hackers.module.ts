import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InstagramHackersPage } from './instagram-hackers';

@NgModule({
  declarations: [
    InstagramHackersPage,
  ],
  imports: [
    IonicPageModule.forChild(InstagramHackersPage),
  ],
})
export class InstagramHackersPageModule {}
